package org.nearby.scanner;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.LinkedHashMap;
import java.util.Map;

public class BleScanner {
    private static BluetoothLeScanner scanner;
    private static ScanCallback callback;
    private static final Map<String, JSONObject> devices = new LinkedHashMap<>();

    public static synchronized void start(Activity activity) {
        if (Build.VERSION.SDK_INT >= 31) {
            if (activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)
                    != PackageManager.PERMISSION_GRANTED ||
                activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                throw new SecurityException("Bluetooth scan/connect permission not granted");
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            if (activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                throw new SecurityException("Location permission not granted");
            }
        }

        BluetoothManager manager =
            (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter = manager.getAdapter();

        if (adapter == null || !adapter.isEnabled()) {
            throw new IllegalStateException("Please turn on Bluetooth");
        }

        scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            throw new IllegalStateException("BLE scanner unavailable on this device");
        }

        devices.clear();
        callback = new ScanCallback() {
            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                saveResult(result);
            }

            @Override
            public void onBatchScanResults(java.util.List<ScanResult> results) {
                for (ScanResult result : results) saveResult(result);
            }

            @Override
            public void onScanFailed(int errorCode) {
                synchronized (devices) {
                    devices.clear();
                    try {
                        devices.put("SCAN_ERROR",
                            new JSONObject().put("name", "Scan error " + errorCode)
                                             .put("address", "")
                                             .put("rssi", 0));
                    } catch (Exception ignored) {}
                }
            }
        };

        ScanSettings settings = new ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build();

        scanner.startScan(null, settings, callback);
    }

    private static void saveResult(ScanResult result) {
        try {
            BluetoothDevice device = result.getDevice();
            String address = device.getAddress();
            String name = "";
            try {
                name = device.getName();
            } catch (SecurityException ignored) {}

            JSONObject item = new JSONObject();
            item.put("name", name == null ? "" : name);
            item.put("address", address == null ? "" : address);
            item.put("rssi", result.getRssi());

            synchronized (devices) {
                devices.put(address, item);
            }
        } catch (Exception ignored) {}
    }

    public static synchronized String getResultsJson() {
        JSONArray array = new JSONArray();
        synchronized (devices) {
            for (JSONObject item : devices.values()) array.put(item);
        }
        return array.toString();
    }

    public static synchronized void stop() {
        if (scanner != null && callback != null) {
            try { scanner.stopScan(callback); } catch (Exception ignored) {}
        }
        callback = null;
        scanner = null;
    }
}
